package com.cg.ams.dao;

public interface QueryConstant {
 public static final String  fetchUser=" select userName, userpassword from User_Master where userType=?";
}
