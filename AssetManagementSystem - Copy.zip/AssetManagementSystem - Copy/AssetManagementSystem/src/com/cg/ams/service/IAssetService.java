package com.cg.ams.service;

import com.cg.ams.bean.UserMasterBean;

public interface IAssetService {



}
