package com.cg.ams.service;

public class AssetServiceImpl implements IAssetService {

	
		
		
		
		
	}

	
		
		
	
